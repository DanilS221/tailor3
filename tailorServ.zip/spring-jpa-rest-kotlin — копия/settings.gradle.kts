rootProject.name = "spring-jpa-rest-kotlin"
