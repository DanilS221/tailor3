package com.tailorproject.dto

data class CountryDto(
    val id: Int,
    val name : String,
    val population: Int,
)
