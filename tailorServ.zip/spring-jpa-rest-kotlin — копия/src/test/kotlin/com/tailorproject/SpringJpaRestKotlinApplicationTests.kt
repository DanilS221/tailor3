package com.tailorproject

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringJpaRestKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
